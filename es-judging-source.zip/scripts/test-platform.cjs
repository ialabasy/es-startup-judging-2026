const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict'),ts=require('typescript');
const {DatabaseSync}=require('node:sqlite');const sqlite=new DatabaseSync(':memory:');sqlite.exec(fs.readFileSync('drizzle/0000_grey_demogoblin.sql','utf8').replaceAll('--> statement-breakpoint',''));
const db={prepare(sql){return {bind(...args){return {async all(){return {results:sqlite.prepare(sql).all(...args)}},async first(){return sqlite.prepare(sql).get(...args)||null},async run(){const r=sqlite.prepare(sql).run(...args);return {meta:{changes:Number(r.changes)}}}}},async all(){return {results:sqlite.prepare(sql).all()}}}},async batch(statements){sqlite.exec('BEGIN');try{const out=[];for(const s of statements)out.push(await s.run());sqlite.exec('COMMIT');return out}catch(e){sqlite.exec('ROLLBACK');throw e}}};
function compile(file,req){const exports={};vm.runInNewContext(ts.transpileModule(fs.readFileSync(file,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText,{exports,require:req,Response,Request,URL,crypto,console});return exports}
const scoring=compile('app/scoring.ts',()=>{});const route=compile('app/api/platform/route.ts',n=>n==='cloudflare:workers'?{env:{DB:db}}:scoring);let checks=0;
function eq(a,b){assert.deepEqual(a,b);checks++}
const admin={id:'admin',email:'ismail.alabasy@gmail.com'};
async function call(body,who=admin){const headers={'oai-authenticated-user-id':who.id,'oai-authenticated-user-email':who.email,origin:'https://test.local','Content-Type':'application/json'};const req=new Request('https://test.local/api/platform',{method:body?'POST':'GET',headers,body:body?JSON.stringify(body):undefined});const r=await (body?route.POST(req):route.GET(req));return {status:r.status,data:await r.json()}}
(async()=>{
eq(scoring.score([5,5,5,5,5,5,5]),100);eq(scoring.score([1,1,1,1,1,1,1]),20);eq(scoring.score([4,4,4,4,4,4,4]),80);eq(scoring.criteria.reduce((n,c)=>n+c.weight,0),100);
eq((await route.GET(new Request('https://test.local/api/platform'))).status,401);
eq((await call(null,{id:'x',email:'outsider@example.invalid'})).status,403);
eq((await call({action:'seed'})).status,200);let d=(await call()).data;eq(d.startups.length,50);eq(d.judges.length,13);eq(d.rooms.length,5);
const j1={id:'auth1',email:'judge11@example.invalid'},j2={id:'auth2',email:'judge12@example.invalid'},s='demo-startup-1-1';
let own=(await call(null,j1)).data;eq(own.startups.length,10);eq(own.judges.length,3);eq(own.me.role,'judge');eq(own.judges.some(j=>'email' in j),false);eq((await call({action:'seed'},j1)).status,403);
let b={action:'saveEvaluation',startup:s,ratings:[4,null,null,null,null,null,null],sustainability:null,comments:'Draft',version:0};let res=await call(b,j1);eq(res.status,200);eq(res.data.version,1);
eq((await call({...b,startup:'demo-startup-2-1'},j1)).status,403);
eq((await call({...b,version:1,submit:true},j1)).status,400);
eq((await call({...b,version:1,ratings:[4,4,4,4,4,4,6]},j1)).status,400);
res=await call({...b,version:1,ratings:[5,5,5,5,5,5,5],sustainability:true,comments:'Final',submit:true},j1);eq(res.status,200);eq(res.data.total,100);
eq((await call({...b,version:2},j1)).status,409);
eq((await call(null,j2)).data.evaluations.length,0);
res=await call({...b,version:0,ratings:[3,3,3,3,3,3,3],sustainability:false,submit:true},j2);eq(res.data.total,60);
d=(await call()).data;let result=scoring.result(d.startups.find(x=>x.id===s),d.judges,d.evaluations);eq(result.average,80);eq(result.complete,false);eq(result.spread,40);eq(result.submitted,2);
eq((await call({action:'exception',id:s,reason:'Approved third judge absence'})).status,200);d=(await call()).data;eq(scoring.result(d.startups.find(x=>x.id===s),d.judges,d.evaluations).complete,true);
eq((await call({action:'upsert',kind:'judge',item:{...d.judges[0],room:'demo-room-2'}})).status,400);
eq((await call({action:'reopen',id:'demo-judge-1-1:'+s,reason:'Panel requested correction'})).status,200);
eq((await call({...b,version:2},j1)).status,409);res=await call({...b,version:3,ratings:[4,4,4,4,4,4,4],sustainability:true,submit:true},j1);eq(res.data.total,80);
eq((await call({action:'settings',target:6,threshold:20,locked:true})).status,400);
for(let i=1;i<=6;i++)eq((await call({action:'finalist',id:'demo-startup-1-'+i,selected:true,reason:'Manual panel review'})).status,200);
eq((await call({action:'settings',target:6,threshold:20,locked:true})).status,200);
eq((await call({action:'reopen',id:'demo-judge-1-1:'+s,reason:'test'})).status,409);
eq((await call({action:'backup'})).data.format,'es-judging-backup-v1');
eq((await call({action:'settings',target:8,threshold:30,locked:false})).status,200);
// Complete a two-judge room; totals are averaged and drafts excluded.
for(let j=1;j<=2;j++)eq((await call({...b,startup:'demo-startup-2-1',version:0,ratings:[4,4,4,4,4,4,4],sustainability:false,submit:true},{id:'auth2'+j,email:`judge2${j}@example.invalid`})).status,200);
d=(await call()).data;result=scoring.result(d.startups.find(x=>x.id==='demo-startup-2-1'),d.judges,d.evaluations);eq(result.average,80);eq(result.complete,true);
// Rehearse a complete 50-startup event (130 independently submitted evaluations).
d=(await call()).data;
for(const startup of d.startups)for(const judge of d.judges.filter(j=>j.room===startup.room)){
const existing=d.evaluations.find(e=>e.startup===startup.id&&e.judge===judge.id);
if(existing?.status==='submitted')continue;
const identity={id:judge.userId||'full-'+judge.id,email:judge.email};
eq((await call({...b,startup:startup.id,version:existing?.version||0,ratings:[4,4,4,4,4,4,4],sustainability:true,submit:true},identity)).status,200);
}
d=(await call()).data;eq(d.evaluations.filter(e=>e.status==='submitted').length,130);eq(d.startups.filter(s=>scoring.result(s,d.judges,d.evaluations).complete).length,50);
// Additional admin roles require an owner, and can be revoked.
eq((await call({action:'adminAccess',name:'Demo Leadership',email:'lead@example.invalid'})).status,200);
eq((await call(null,{id:'lead-user',email:'lead@example.invalid'})).data.me.role,'admin');
eq((await call({action:'adminAccess',name:'Other',email:'other@example.invalid'},{id:'lead-user',email:'lead@example.invalid'})).status,403);
eq((await call({action:'adminAccess',remove:true,id:'admin-lead@example.invalid'})).status,200);
eq((await call({action:'clearDemo'})).status,200);d=(await call()).data;eq(d.startups.length,0);eq(d.judges.length,0);eq(d.evaluations.length,0);
console.log(`PASS: ${checks} assertions; real SQLite migrations, 50 startups, 5 rooms, 13 judges; authentication, authorization, drafts, scoring, locks, optimistic conflicts, panel averages, exceptions, finalist decisions, backup and rehearsal cleanup.`);
})().catch(e=>{console.error(e);process.exit(1)});
