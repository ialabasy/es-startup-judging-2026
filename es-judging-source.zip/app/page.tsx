'use client';
import { useState, useEffect, useRef } from 'react';
import { criteria, score, result } from './scoring';
import { LayoutDashboard, DoorOpen, Users, Lightbulb, Trophy, Download, ShieldCheck, ArrowLeft, ChevronRight, Info, Check, Search, Plus, RefreshCw, Activity, ClipboardList } from 'lucide-react';
type Any = any;
async function api(body?: Any) { const r = await fetch('/api/platform', { method: body ? 'POST' : 'GET', headers: body ? { 'Content-Type': 'application/json' } : undefined, body: body ? JSON.stringify(body) : undefined }); const d: any = await r.json(); if (!r.ok)
    throw new Error(d.error || 'Request failed'); return d; }
function download(name: string, content: string, type = 'text/csv') { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([content], { type })); a.download = name; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 1000); }
function csv(rows: Any[][]) { return rows.map(r => r.map(x => '"' + String(x ?? '').replace(/^[=+@\-\t\r]/, "'$&").replaceAll('"', '""') + '"').join(',')).join('\r\n'); }
function parseCSV(s: string) { const rows: string[][] = []; let row: string[] = [], cell = '', quoted = false; for (let i = 0; i < s.length; i++) {
    const c = s[i];
    if (c === '"') {
        if (quoted && s[i + 1] === '"') {
            cell += '"';
            i++;
        }
        else
            quoted = !quoted;
    }
    else if (c === ',' && !quoted) {
        row.push(cell);
        cell = '';
    }
    else if ((c === '\n' || c === '\r') && !quoted) {
        if (c === '\r' && s[i + 1] === '\n')
            i++;
        row.push(cell);
        if (row.some(Boolean))
            rows.push(row);
        row = [];
        cell = '';
    }
    else
        cell += c;
} if (quoted)
    throw new Error('Unclosed CSV quote.'); row.push(cell); if (row.some(Boolean))
    rows.push(row); return rows; }
const navs = [['Overview', LayoutDashboard], ['Rooms', DoorOpen], ['Startups', Lightbulb], ['Judges', Users], ['Rankings', Activity], ['Finalist review', Trophy], ['Exports & setup', Download], ['Audit trail', ShieldCheck]] as const;
export default function Platform() {
    const [data, setData] = useState<Any>(null), [error, setError] = useState(''), [page, setPage] = useState('Overview'), [selected, setSelected] = useState<Any>(null), [edit, setEdit] = useState<Any>(null), [query, setQuery] = useState(''), [room, setRoom] = useState(''), [status, setStatus] = useState(''), [judgeFilter, setJudgeFilter] = useState(''), [busy, setBusy] = useState(false), [preview, setPreview] = useState(''), [notice, setNotice] = useState('');
    const load = async () => { try {
        setData(await api());
        setError('');
    }
    catch (e: Any) {
        setError(e.message);
    } };
    useEffect(() => { load(); const t = setInterval(load, 10000); return () => clearInterval(t); }, []);
    async function act(b: Any) { setBusy(true); try {
        const r = await api(b);
        await load();
        return r;
    }
    catch (e: Any) {
        setNotice(e.message);
        throw e;
    }
    finally {
        setBusy(false);
    } }
    if (!data)
        return <main className="login"><img src="/es-logo.png" alt="ES"/><span className="eyebrow">STARTUP COMPETITION 2026</span><h1>Great ideas deserve<br />thoughtful evaluation.</h1><p>{error || 'Connecting to your judging workspace…'}</p>{error && <><a className="primary button" href="/signin-with-chatgpt?return_to=/" target="_top">Sign in with ChatGPT</a><p className="small">Use the email registered with ES Academics. Judge access is invitation-only.</p></>}</main>;
    const isAdmin = data.me.role === 'admin';
    const judging = !isAdmin || !!preview;
    const judge = preview ? data.judges.find((j: Any) => j.id === preview) : data.me;
    const rooms = data.rooms;
    const jud = data.judges;
    const startups = data.startups;
    const evals = data.evaluations;
    const settings = data.settings;
    const metrics = startups.map((s: Any) => ({ ...s, ...result(s, jud, evals) }));
    const expected = metrics.reduce((n: number, s: Any) => n + s.expected, 0);
    const submitted = metrics.reduce((n: number, s: Any) => n + s.submitted, 0);
    const complete = metrics.filter((s: Any) => s.complete).length;
    const filtered = metrics.filter((s: Any) => (!room || s.room === room) && (!judgeFilter || jud.some((j: Any) => j.id === judgeFilter && j.room === s.room)) && (!query || (s.name + ' ' + s.team + ' ' + s.industry).toLowerCase().includes(query.toLowerCase())) && (!status || (status === 'complete' ? s.complete : !s.complete)));
    const roomName = (id: string) => rooms.find((r: Any) => r.id === id)?.name || 'Unassigned';
    const go = (p: string) => { setPage(p); setSelected(null); setQuery(''); setRoom(''); setStatus(''); setJudgeFilter(''); };
    const ask = (action: string, id: string, selected?: boolean) => { const reason = prompt(action === 'reopen' ? 'Why should this evaluation be reopened?' : action === 'exception' ? 'Why is completion approved with missing evaluations?' : 'Record the panel’s reason for this finalist decision.'); if (reason?.trim())
        act({ action, id, selected, reason }).catch(() => { }); };
    const exportResults = () => download('ES_results.csv', csv([['Startup', 'Team', 'Room', 'Average /100', 'Submitted', 'Required', 'Complete', 'Exception', 'Finalist', 'Decision reason'], ...metrics.map((s: Any) => [s.name, s.team, roomName(s.room), s.average?.toFixed(2), s.submitted, s.expected, s.complete ? 'Yes' : 'No', s.exception, s.finalist ? 'Yes' : 'No', s.finalistReason])]));
    const exportEvaluations = () => download('ES_evaluations.csv', csv([['Startup', 'Judge', 'Room', 'Status', ...criteria.map(c => c.name), 'Weighted score /100', 'Sustainability', 'Comments', 'Updated'], ...evals.map((e: Any) => [startups.find((s: Any) => s.id === e.startup)?.name, jud.find((j: Any) => j.id === e.judge)?.name, roomName(startups.find((s: Any) => s.id === e.startup)?.room), e.status, ...e.ratings, e.status === 'submitted' ? score(e.ratings).toFixed(2) : '', e.sustainability === null ? '' : e.sustainability ? 'Yes' : 'No', e.comments, e.updatedAt])]));
    const table = (list: Any[]) => <div className="table-wrap"><table><thead><tr><th>Startup / team</th><th>Room</th><th>Evaluations</th><th>Average / 100</th><th>Status</th><th></th></tr></thead><tbody>{list.map((s: Any) => <tr key={s.id} onClick={() => setSelected(s)} tabIndex={0} onKeyDown={e => e.key === 'Enter' && setSelected(s)}><td><strong>{s.name}</strong><small>{s.team}</small></td><td>{roomName(s.room)}</td><td>{s.submitted} / {s.expected}<div className="mini-track"><i style={{ width: (s.expected ? s.submitted / s.expected * 100 : 0) + '%' }}/></div></td><td className="score">{s.average === null ? '—' : s.average.toFixed(2)}{s.spread >= settings.threshold && <small className="warn">Score disagreement</small>}</td><td><span className={'badge ' + (s.complete ? 'green' : '')}>{s.complete ? 'Complete' : s.submitted ? 'In progress' : 'Pending'}</span>{s.finalist && <span className="badge yellow">Finalist</span>}</td><td><ChevronRight size={16}/></td></tr>)}</tbody></table>{!list.length && <div className="empty">No startups match this view.</div>}</div>;
    const filters = <div className="filters"><label className="search"><Search size={16}/><input aria-label="Search startups" placeholder="Search startups or teams" value={query} onChange={e => setQuery(e.target.value)}/></label><select aria-label="Filter room" value={room} onChange={e => setRoom(e.target.value)}><option value="">All rooms</option>{rooms.map((r: Any) => <option key={r.id} value={r.id}>{r.name}</option>)}</select><select aria-label="Filter completion" value={status} onChange={e => setStatus(e.target.value)}><option value="">All statuses</option><option value="complete">Complete</option><option value="pending">Pending submissions</option></select><select aria-label="Filter judge" value={judgeFilter} onChange={e => setJudgeFilter(e.target.value)}><option value="">All judges</option>{jud.map((j: Any) => <option key={j.id} value={j.id}>{j.name}</option>)}</select></div>;
    return <div className="shell"><aside className="sidebar"><a className="brand" href="/"><img src="/es-logo.png" alt="Entrepreneurs’ Society logo"/><span>Entrepreneurs’<br />Society <b>AUC</b></span></a><div className="side-label">COMPETITION WORKSPACE</div><div className="event-name">Startup Competition <span>2026</span></div><nav>{(judging ? [['Judge portal', ClipboardList] as const] : navs).map(([n, Icon]) => <button key={n} className={page === n || (judging && n === 'Judge portal') ? 'nav active' : 'nav'} onClick={() => go(n)}><Icon size={18}/>{n}{n === 'Overview' && <span className="nav-dot"/>}</button>)}</nav><div className="side-bottom"><div className="event-date"><span className="date-day">17</span><div>November 2026<small>Filtration · 5–8 PM</small></div></div><div className="user"><span className="avatar">{data.me.name.slice(0, 1)}</span><div><strong>{data.me.name}</strong><small>{isAdmin ? 'Academics administrator' : 'Assigned judge'}</small></div></div><a className="small muted" href="/signout-with-chatgpt?return_to=/" target="_top">Sign out</a></div></aside><div className="workspace"><header className="topbar"><span>ES / Startup Competition / <strong>{judging ? 'Judge portal' : page}</strong></span><div><span className="live-dot"/> Live workspace <button className="icon" onClick={load} title="Refresh"><RefreshCw size={15}/></button></div></header><main>
    {notice && <div className="alert" role="alert">{notice}<button onClick={() => setNotice('')}>Dismiss</button></div>}{error && <div className="alert">Connection lost: {error}. Saved data remains available; retry before continuing.</div>}
    {startups.some((s: Any) => s.demo) && <div className="demo-banner">REHEARSAL DATA · Fictional startups and judges. Do not use these records for competition decisions.{preview && <button onClick={() => { setPreview(''); setSelected(null); }}>Exit judge rehearsal</button>}</div>}
        {judging ? <><div className="page-heading"><div><span className="eyebrow">YOUR JUDGING WORKSPACE</span><h1>Welcome, {judge.name}.</h1><p>{roomName(judge.room)} · Independent evaluations, thoughtful feedback.</p></div><span className="badge">{evals.filter((e: Any) => e.judge === judge.id && e.status === 'submitted').length} submitted</span></div>{selected ? <Evaluation key={selected.id + judge.id} startup={selected} judge={judge} saved={evals.find((e: Any) => e.startup === selected.id && e.judge === judge.id)} locked={settings.locked} onBack={() => { setSelected(null); load(); }} onSaved={load}/> : <><section className="panel"><div className="panel-head"><h2>Your panel</h2><span className="muted">{roomName(judge.room)}</span></div><div className="panel-judges">{jud.filter((j: Any) => j.room === judge.room && j.active !== false).map((j: Any) => <div className="judge-chip" key={j.id}><span className="avatar">{j.name[0]}</span><div><strong>{j.name}</strong><small>{j.organization}{j.title ? ' · ' + j.title : ''}</small>{j.linkedin && <a href={j.linkedin} target="_blank" rel="noreferrer">LinkedIn ↗</a>}</div></div>)}</div></section><h2 className="section-title">Assigned startups</h2><div className="startup-grid">{startups.filter((s: Any) => s.room === judge.room).map((s: Any) => { const e = evals.find((e: Any) => e.startup === s.id && e.judge === judge.id); return <button className="startup-card" key={s.id} onClick={() => setSelected(s)}><span className={'badge ' + (e?.status === 'submitted' ? 'green' : '')}>{e?.status === 'submitted' ? 'Submitted' : e ? 'Draft' : 'Not started'}</span><h3>{s.name}</h3><p>{s.description || 'No description provided.'}</p><span className="card-link">{e?.status === 'submitted' ? 'View evaluation' : 'Open evaluation'} <ChevronRight size={15}/></span></button>; })}</div></>}</> : <>
        <div className="page-heading"><div><span className="eyebrow">FILTRATION DAY · 17 NOVEMBER 2026</span><h1>{selected ? selected.name : page === 'Overview' ? 'Every idea. A fair hearing.' : page}</h1><p>{selected ? 'Evaluation detail and panel feedback.' : page === 'Overview' ? 'Your competition, from the first pitch to the final decision.' : 'Startup Competition 2026 · ES Academics'}</p></div><div className="heading-actions">{selected ? <button onClick={() => setSelected(null)}><ArrowLeft size={16}/> Back</button> : <><span className={'badge ' + (settings.locked ? '' : 'green')}>{settings.locked ? 'Results locked' : 'Judging open'}</span><button onClick={exportResults}><Download size={16}/> Export results</button></>}</div></div>
            {selected ? <><div className="detail-grid"><section className="panel padded"><span className="eyebrow">{roomName(selected.room)} · {selected.industry || 'Uncategorised'}</span><h2>{selected.team || selected.name}</h2><p>{selected.description}</p><h4>Problem</h4><p>{selected.problem || 'Not provided'}</p><h4>Solution</h4><p>{selected.solution || 'Not provided'}</p>{selected.deck && <a href={selected.deck} target="_blank" rel="noreferrer">Open pitch deck ↗</a>}</section><section className="panel padded"><h2>Panel result</h2><div className="big-score">{selected.average?.toFixed(2) ?? '—'}<small>/ 100</small></div><p>{selected.submitted} of {selected.expected} required evaluations submitted.</p>{selected.exception && <p className="warn">Approved exception: {selected.exception}</p>}<button onClick={() => ask('exception', selected.id)}>Record completion exception</button><button onClick={() => ask('finalist', selected.id, !selected.finalist)}>{selected.finalist ? 'Remove finalist' : 'Select as finalist'}</button></section></div><section className="panel padded"><h2>Individual evaluations</h2>{jud.filter((j: Any) => j.room === selected.room && j.active !== false).map((j: Any) => { const e = evals.find((e: Any) => e.judge === j.id && e.startup === selected.id); return <div className="evaluation-detail" key={j.id}><div className="panel-head"><h3>{j.name} <small>{j.organization}</small></h3><span className="badge">{e?.status || 'Missing'}</span><strong>{e?.status === 'submitted' ? score(e.ratings).toFixed(2) + '/100' : '—'}</strong></div>{e && <><div className="criterion-summary">{criteria.map((c, i) => <div key={c.name}><span>{c.name}</span><b>{e.ratings[i] ?? '—'} / 5</b></div>)}</div><p><b>Sustainability:</b> {e.sustainability === null ? 'Unanswered' : e.sustainability ? 'Yes' : 'No'}</p><p className="feedback">{e.comments || 'No comments.'}</p>{e.status === 'submitted' && <button onClick={() => ask('reopen', e.id)}>Reopen with reason</button>}</>}</div>; })}</section></> : <>
            {page === 'Overview' && <><div className="stats">{[['Registered startups', startups.length, 'Across five judging rooms'], ['Judging panel', jud.filter((j: Any) => j.active !== false).length, 'Two or three judges per room'], ['Submitted evaluations', submitted, `${Math.max(0, expected - submitted)} still pending`], ['Fully evaluated', complete, `of ${startups.length} startups`]].map(([label, value, sub], i) => <div className="stat" key={label}><span>{label}</span><strong>{value}<i className={'stat-dot c' + i}/></strong><small>{sub}</small></div>)}</div><section className="progress-panel"><div><span className="eyebrow">LIVE PROGRESS</span><h2>One pitch closer.</h2><p>{submitted} of {expected} required evaluations submitted</p></div><div className="progress-right"><strong>{expected ? Math.round(submitted / expected * 100) : 0}%</strong><div className="progress-track"><i style={{ width: (expected ? submitted / expected * 100 : 0) + '%' }}/></div><small>Updated every 10 seconds</small></div></section><div className="panel-head section-title"><h2>Judging rooms</h2><button className="text-button" onClick={() => go('Rooms')}>Manage rooms <ChevronRight size={15}/></button></div><div className="room-grid">{rooms.map((r: Any, i: number) => { const ss = metrics.filter((s: Any) => s.room === r.id), js = jud.filter((j: Any) => j.room === r.id && j.active !== false); return <button className="room-card" key={r.id} onClick={() => { go('Rankings'); setRoom(r.id); }}><div className="room-icon"><DoorOpen size={21}/><span>0{i + 1}</span></div><h3>{r.name}</h3><p>{ss.length} startups · {js.length} judges</p><div className="mini-track"><i style={{ width: (ss.length ? ss.filter((s: Any) => s.complete).length / ss.length * 100 : 0) + '%' }}/></div><small>{ss.filter((s: Any) => s.complete).length} / {ss.length} complete</small>{(js.length < 2 || js.length > 3) && <small className="warn">Requires 2–3 active judges</small>}</button>; })}{!rooms.length && <button className="room-card" onClick={() => setEdit({ kind: 'room', item: { name: 'Room 1' } })}><Plus /><h3>Create first room</h3><p>Prepare your judging panels.</p></button>}</div><section className="panel"><div className="panel-head"><h2>Evaluation activity</h2><span className="small muted">Independent scores. Shared progress.</span></div>{table(metrics.slice(0, 10))}</section>{!startups.length && <section className="empty panel"><h2>Start with a full rehearsal.</h2><p>Create 50 fictional startups, 13 judges and five rooms to practise the entire workflow.</p><button className="primary" onClick={() => act({ action: 'seed' }).catch(() => { })} disabled={busy}>Load fictional rehearsal data</button><p className="small">Or add your actual rooms, startups and judges from the menu.</p></section>}</>}
            {page === 'Rooms' && <><div className="toolbar"><p>Assignments freeze once an evaluation has started.</p><button className="primary" onClick={() => setEdit({ kind: 'room', item: { name: '' } })}><Plus size={16}/> Add room</button></div>{rooms.map((r: Any) => <section className="panel padded" key={r.id}><div className="panel-head"><h2>{r.name}</h2><div><button onClick={() => setEdit({ kind: 'room', item: r })}>Edit</button><button onClick={() => confirm('Remove this empty room?') && act({ action: 'remove', id: r.id }).catch(() => { })}>Remove</button></div></div><div className="panel-judges">{jud.filter((j: Any) => j.room === r.id && j.active !== false).map((j: Any) => <div className="judge-chip" key={j.id}><span className="avatar">{j.name[0]}</span><div><strong>{j.name}</strong><small>{j.organization}</small></div></div>)}</div>{table(metrics.filter((s: Any) => s.room === r.id))}</section>)}</>}
            {page === 'Startups' && <><div className="toolbar">{filters}<button className="primary" onClick={() => setEdit({ kind: 'startup', item: { name: '', room: '' } })}><Plus size={16}/> Add startup</button></div>{table(filtered)}<div className="edit-list">{filtered.map((s: Any) => <button key={s.id} onClick={() => setEdit({ kind: 'startup', item: s })}>Edit {s.name}</button>)}</div></>}
            {page === 'Judges' && <><div className="toolbar"><p>Access is linked to each judge’s verified sign-in email.</p><button className="primary" onClick={() => setEdit({ kind: 'judge', item: { name: '', email: '', room: '', active: true } })}><Plus size={16}/> Add judge</button></div><div className="startup-grid">{jud.map((j: Any) => { const ee = evals.filter((e: Any) => e.judge === j.id && e.status === 'submitted'); return <section className="panel padded" key={j.id}><span className="avatar">{j.name[0]}</span><h3>{j.name}</h3><p>{j.organization}<br />{j.title}</p><small>{j.email}</small><p><span className="badge">{roomName(j.room)}</span> <span className={'badge ' + (j.active !== false ? 'green' : '')}>{j.active !== false ? 'Active' : 'Disabled'}</span></p><p>{ee.length} submitted / {startups.filter((s: Any) => s.room === j.room).length} assigned</p>{j.linkedin && <a href={j.linkedin} target="_blank" rel="noreferrer">LinkedIn ↗</a>}<div className="button-row"><button onClick={() => setEdit({ kind: 'judge', item: j })}>Edit judge</button>{j.demo && <button onClick={() => { setPreview(j.id); setSelected(null); }}>Rehearse as judge</button>}</div></section>; })}</div></>}
            {page === 'Rankings' && <>{filters}<div className="note"><Info size={17}/><span>Rankings use mean submitted scores. Incomplete results remain provisional. Cross-room scores require panel deliberation.</span></div>{rooms.filter((r: Any) => !room || room === r.id).map((r: Any) => <section className="panel" key={r.id}><div className="panel-head"><h2>{r.name}</h2><span className="muted">Highest average first · ties share the same score</span></div>{table(filtered.filter((s: Any) => s.room === r.id).sort((a: Any, b: Any) => (b.average ?? -1) - (a.average ?? -1)))}</section>)}</>}
            {page === 'Finalist review' && <><div className="progress-panel"><div><span className="eyebrow">HUMAN PANEL DECISION</span><h2>{startups.filter((s: Any) => s.finalist).length} of {settings.target} finalists selected</h2><p>Review room context, missing evaluations and score disagreements before selecting.</p></div><button className="primary" onClick={() => act({ action: 'settings', ...settings, locked: !settings.locked }).catch(() => { })}>{settings.locked ? 'Unlock results' : 'Lock final results'}</button></div>{filters}{table(filtered)}<div className="note">Open a startup to record a finalist decision and the panel’s reason. A score never automatically qualifies a team.</div></>}
            {page === 'Exports & setup' && <><div className="detail-grid"><section className="panel padded"><h2>Results & recovery</h2><p>Download both result files and a full backup before and after judging.</p><div className="button-column"><button onClick={exportResults}><Download size={16}/> Startup results CSV</button><button onClick={exportEvaluations}><Download size={16}/> Ratings, comments & sustainability CSV</button><button onClick={async () => { try {
                const b = await api({ action: 'backup' });
                download('ES_backup_' + new Date().toISOString().slice(0, 10) + '.json', JSON.stringify(b, null, 2), 'application/json');
            }
            catch (e: Any) {
                setNotice(e.message);
            } }}><ShieldCheck size={16}/> Download full JSON backup</button><button onClick={() => window.print()}>Print current view</button></div><p className="small">CSV files open in Excel. Full backups include drafts and audit history. Recovery requires an operator to restore the database; see README.</p></section><section className="panel padded"><h2>Competition settings</h2><form onSubmit={e => { e.preventDefault(); const f = new FormData(e.currentTarget); act({ action: 'settings', threshold: Number(f.get('threshold')), target: Number(f.get('target')), locked: settings.locked }).catch(() => { }); }}><label>Disagreement threshold (points)<input key={'t' + settings.threshold} name="threshold" type="number" min="1" max="100" defaultValue={settings.threshold}/></label><label>Finalist target<select key={'f' + settings.target} name="target" defaultValue={settings.target}><option value="6">6 finalists</option><option value="8">8 finalists</option></select></label><button className="primary" disabled={busy}>Save settings</button></form><p className="small">Flags highlight score spreads for discussion; scores remain unchanged.</p></section></div><section className="panel padded"><h2>Import competition information</h2><p>Import a UTF-8 CSV using these headers. Room names must match existing rooms. Imports are processed one row at a time; successful rows stay saved if a later row fails.</p>{(['startup', 'judge'] as const).map(kind => <div className="import-row" key={kind}><h3>{kind === 'startup' ? 'Startups' : 'Judges'}</h3><button onClick={() => download(kind + '_template.csv', csv([kind === 'startup' ? ['name', 'team', 'description', 'problem', 'solution', 'industry', 'room', 'deck'] : ['name', 'email', 'organization', 'title', 'linkedin', 'room']]))}>Download CSV template</button><label className="file-button">Import CSV<input type="file" accept=".csv" onChange={async (e) => { const file = e.target.files?.[0]; if (!file)
                return; let count = 0; try {
                const rows = parseCSV(await file.text());
                if (rows.length < 2)
                    throw new Error('CSV contains no data rows.');
                const heads = rows.shift()!.map(x => x.trim().replace(/^\uFEFF/, ''));
                if (!heads.includes('name') || (kind === 'judge' && !heads.includes('email')))
                    throw new Error('Missing required name or email header.');
                for (const row of rows) {
                    const item: Any = Object.fromEntries(heads.map((h, i) => [h, row[i] || '']));
                    if (item.room) {
                        const r = rooms.find((r: Any) => r.name === item.room || r.id === item.room);
                        if (!r)
                            throw new Error('Unknown room: ' + item.room);
                        item.room = r.id;
                    }
                    await api({ action: 'upsert', kind, item });
                    count++;
                }
                setNotice(`${count} ${kind} records imported.`);
            }
            catch (err: Any) {
                setNotice(`${count} rows imported. Import stopped: ${err.message}`);
            }
            finally {
                await load();
                e.target.value = '';
            } }}/></label></div>)}</section><section className="panel padded"><h2>Administrator access</h2><p>Only Ismail’s owner accounts can grant or revoke administrator roles. Add the same email to the site’s visitor sharing settings as well.</p><form onSubmit={async (e) => { e.preventDefault(); const form = e.currentTarget; const f = new FormData(form); try {
                await act({ action: 'adminAccess', name: f.get('name'), email: f.get('email') });
                form.reset();
            }
            catch { } }}><div className="button-row"><label>Name<input name="name" required/></label><label>Sign-in email<input name="email" type="email" required/></label><button className="primary" disabled={busy}>Add administrator</button></div></form>{data.admins?.map((a: Any) => <div className="import-row" key={a.id}><strong>{a.name}</strong><span>{a.email}</span><button onClick={() => confirm('Revoke administrator access?') && act({ action: 'adminAccess', remove: true, id: a.id }).catch(() => { })}>Revoke</button></div>)}</section><section className="panel padded"><h2>Rehearsal & event handover</h2><p>Use fictional data to practise, then download a backup and clear it before importing actual entries. Judge access requires inviting registered emails through the site’s sharing settings.</p><div className="button-row"><button onClick={() => act({ action: 'seed' }).catch(() => { })}>Load rehearsal data</button><button className="danger" onClick={() => confirm('Delete all fictional rehearsal startups, judges and their evaluations? Real records are preserved.') && act({ action: 'clearDemo' }).catch(() => { })}>Clear fictional data</button></div></section></>}
            {page === 'Audit trail' && <section className="panel"><div className="panel-head"><h2>Administrative & evaluation history</h2><span className="small muted">Latest 500 events · full history in backup</span></div><div className="table-wrap"><table><thead><tr><th>Time</th><th>Action</th><th>Actor</th><th>Details</th></tr></thead><tbody>{data.audit.map((a: Any) => <tr key={a.id}><td>{new Date(a.time).toLocaleString('en-GB', { timeZone: 'Africa/Cairo' })}</td><td>{a.action}</td><td>{jud.find((j: Any) => j.id === a.actor || j.userId === a.actor)?.name || 'Administrator'}</td><td><span className="audit-body">{a.body}</span></td></tr>)}</tbody></table></div></section>}
            </>}</>}
    <footer><span>THE ENTREPRENEURS’ SOCIETY · AUC</span><span>Built for ideas. Designed for fair decisions.</span></footer></main></div>
    {edit && <div className="modal-overlay"><section className="modal" role="dialog" aria-modal="true" aria-label={'Edit ' + edit.kind}><div className="panel-head"><h2>{edit.item.id ? 'Edit' : 'Add'} {edit.kind}</h2><button onClick={() => setEdit(null)}>Close</button></div><form onSubmit={async (e) => { e.preventDefault(); const f = new FormData(e.currentTarget); const item = { ...edit.item, ...Object.fromEntries(f) }; if (edit.kind === 'judge')
        item.active = f.get('active') === 'true'; try {
        await act({ action: 'upsert', kind: edit.kind, item });
        setEdit(null);
    }
    catch { } }}>{(edit.kind === 'room' ? ['name'] : edit.kind === 'judge' ? ['name', 'email', 'organization', 'title', 'linkedin', 'room', 'active'] : ['name', 'team', 'description', 'problem', 'solution', 'industry', 'room', 'deck']).map(f => <label key={f}>{({ name: 'Name', team: 'Team name', description: 'Short description', problem: 'Problem', solution: 'Solution', industry: 'Industry', room: 'Assigned room', deck: 'Pitch deck HTTPS URL', email: 'Sign-in email', organization: 'Organization', title: 'Professional title', linkedin: 'LinkedIn HTTPS URL', active: 'Account status' } as Any)[f]}{f === 'room' ? <select name={f} defaultValue={edit.item[f] || ''}><option value="">Unassigned</option>{rooms.map((r: Any) => <option key={r.id} value={r.id}>{r.name}</option>)}</select> : f === 'active' ? <select name={f} defaultValue={edit.item.active === false ? 'false' : 'true'}><option value="true">Active</option><option value="false">Disabled</option></select> : ['description', 'problem', 'solution'].includes(f) ? <textarea name={f} defaultValue={edit.item[f] || ''} maxLength={10000}/> : <input name={f} required={f === 'name' || f === 'email'} type={f === 'email' ? 'email' : ['deck', 'linkedin'].includes(f) ? 'url' : 'text'} defaultValue={edit.item[f] || ''} maxLength={f === 'name' ? 200 : 2000}/>}</label>)}<div className="button-row"><button className="primary" disabled={busy}>Save {edit.kind}</button>{edit.item.id && <button type="button" className="danger" onClick={async () => { if (confirm('Remove this record? Records with evaluations cannot be removed.'))
        try {
            await act({ action: 'remove', id: edit.item.id });
            setEdit(null);
        }
        catch { } }}>Remove</button>}</div></form></section></div>}
    </div>;
}
function Evaluation({ startup, judge, saved, locked, onBack, onSaved }: Any) {
    const [ratings, setRatings] = useState<(number | null)[]>(saved?.ratings || Array(7).fill(null)), [sustainability, setSustainability] = useState<boolean | null>(saved?.sustainability ?? null), [comments, setComments] = useState(saved?.comments || ''), [version, setVersion] = useState(saved?.version || 0), [state, setState] = useState(saved?.status === 'submitted' ? 'Submitted' : 'Ready'), [help, setHelp] = useState<number | null>(null), [err, setErr] = useState(''), [sending, setSending] = useState(false), [submitted, setSubmitted] = useState(saved?.status === 'submitted');
    const dirty = useRef(false), chain = useRef(Promise.resolve()), values = useRef<Any>({ ratings, sustainability, comments, version });
    values.current = { ratings, sustainability, comments, version };
    const disabled = submitted || locked || sending;
    const [rev, setRev] = useState(0);
    const changed = () => { dirty.current = true; setState('Unsaved changes'); setRev(n => n + 1); };
    const save = (submit = false) => { const snapshot = { ...values.current }; chain.current = chain.current.catch(() => { }).then(async () => { setState('Saving…'); const out = await api({ action: 'saveEvaluation', startup: startup.id, judge: judge.id, ...snapshot, version: values.current.version, submit }); values.current.version = out.version; setVersion(out.version); if (submit) {
        setSubmitted(true);
        setState('Submitted');
        onSaved();
    }
    else
        setState('All changes saved'); setErr(''); }).catch((e: Any) => { dirty.current = true; setState('Save failed'); setErr(e.message); throw e; }); return chain.current; };
    useEffect(() => { if (!dirty.current || disabled)
        return; const t = setTimeout(() => { dirty.current = false; save().catch(() => { }); }, 600); return () => clearTimeout(t); }, [rev]);
    useEffect(() => { const f = (e: BeforeUnloadEvent) => { if (dirty.current || state === 'Saving…') {
        e.preventDefault();
        e.returnValue = '';
    } }; window.addEventListener('beforeunload', f); return () => window.removeEventListener('beforeunload', f); }, [state]);
    return <><button className="text-button" onClick={async () => { try {
        if (dirty.current && !submitted)
            await save();
        else
            await chain.current;
    }
    catch {
        return;
    } onBack(); }}><ArrowLeft size={16}/> All assigned startups</button><div className="evaluation-title"><div><span className="eyebrow">{startup.industry || 'STARTUP EVALUATION'}</span><h2>{startup.name}</h2><p>{startup.team} · {startup.description}</p></div><span className={'badge ' + (state === 'All changes saved' || submitted ? 'green' : '')}>{state}</span></div><section className="panel padded"><div className="detail-grid"><div><h4>Problem</h4><p>{startup.problem || 'Not provided'}</p></div><div><h4>Proposed solution</h4><p>{startup.solution || 'Not provided'}</p></div></div>{startup.deck && <a href={startup.deck} target="_blank" rel="noreferrer">Pitch deck ↗</a>}</section><div className="note"><Info size={18}/><span>Assess idea-stage reasoning and evidence. Traction, a working MVP, detailed forecasts and a complete GTM are not required.</span></div>{err && <div className="alert" role="alert">{err}<button onClick={() => save().catch(() => { })}>Retry save</button><button onClick={() => download('unsaved-evaluation.json', JSON.stringify({ startup: startup.id, judge: judge.id, ratings, sustainability, comments }, null, 2), 'application/json')}>Download local copy</button></div>}
    <section className="panel ratings-panel"><div className="panel-head"><h2>The seven criteria</h2><span className="muted small">1 = lowest · 5 = highest</span></div>{criteria.map((c, i) => <div className="criterion" key={c.name}><div className="criterion-label"><span className="criterion-no">0{i + 1}</span><div><h3>{c.name} <button className="info" aria-label={'Scoring guide for ' + c.name} onClick={() => setHelp(help === i ? null : i)}><Info size={15}/></button></h3><small>{c.weight}% of total score</small></div></div><div className="ratings" role="group" aria-label={c.name}>{[1, 2, 3, 4, 5].map(n => <button disabled={disabled} key={n} aria-pressed={ratings[i] === n} className={ratings[i] === n ? 'chosen' : ''} onClick={() => { setRatings(r => r.map((x, k) => k === i ? n : x)); changed(); }}>{n}</button>)}</div>{help === i && <div className="anchors"><p>{c.about}</p>{c.anchors.map((a, k) => <p key={a}><b>{k + 1}</b> {a}</p>)}<small>Idea stage: evaluate credible reasoning and learning; do not require traction, a completed MVP, detailed forecasts or a full GTM.</small></div>}</div>)}</section><section className="panel padded sustainability"><div><span className="eyebrow">SEPARATE AWARD CONSIDERATION</span><h3>Does this startup demonstrate a meaningful environmental or social sustainability contribution?</h3><p>A credible positive contribution is central to the idea or meaningfully incorporated into the solution. This does not affect the weighted score.</p></div><div className="ratings">{[true, false].map(v => <button disabled={disabled} key={String(v)} className={sustainability === v ? 'chosen' : ''} aria-pressed={sustainability === v} onClick={() => { setSustainability(v); changed(); }}>{v ? 'YES' : 'NO'}</button>)}</div></section><section className="panel padded"><h3>Judge comments</h3><p>Record your observations, questions and useful feedback for the team.</p><textarea aria-label="Judge comments" className="comments" value={comments} maxLength={20000} disabled={disabled} onChange={e => { setComments(e.target.value); changed(); }} placeholder="What stands out? What should the team test next?"/></section><div className="submit-bar"><div><span className="muted small">{submitted ? 'Submitted score' : 'Current weighted score'}</span><strong>{score(ratings).toFixed(2)} <small>/ 100</small></strong><small>{ratings.filter(Boolean).length}/7 criteria completed{ratings.some(x => x === null) ? ' · provisional' : ''}</small></div><div><p className="small muted">{submitted ? 'Locked. Contact ES Academics to request reopening.' : 'You can change your ratings until submission.'}</p>{!submitted && <button className="primary" disabled={disabled || ratings.some(x => x === null) || sustainability === null} onClick={async () => { if (!confirm('Submit and lock this evaluation? Only an administrator can reopen it.'))
        return; setSending(true); try {
        await save(true);
        dirty.current = false;
    }
    catch { }
    finally {
        setSending(false);
    } }}><Check size={17}/> {sending ? 'Submitting…' : 'Submit evaluation'}</button>}</div></div></>;
}
