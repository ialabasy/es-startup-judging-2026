'use client';
import { useState, useEffect } from 'react';
import Evaluation from '../components/JudgeEvaluation';
const startup = { id: 'preview-only', name: 'Loop Campus', team: 'Fictional Team', industry: 'Circular economy', description: 'A student-to-student marketplace for reusing course supplies.', problem: 'Students buy supplies they use only briefly, while others struggle to find affordable materials.', solution: 'Connect students who have spare supplies with students who need them. Start by testing one department and a simple reservation process.' };
const judge = { id: 'preview-judge', name: 'Demo Judge' };
export default function JudgePreview() {
    const [ready, setReady] = useState(false), [saved, setSaved] = useState<any>(null), [revision, setRevision] = useState(0), [list, setList] = useState(false), [device, setDevice] = useState('390'), [full, setFull] = useState(false), [storageError, setStorageError] = useState('');
    useEffect(() => { setFull(new URLSearchParams(location.search).get('view') === 'full' || window.innerWidth <= 600); try {
        const s = localStorage.getItem('es-judge-interface-preview');
        if (s)
            setSaved(JSON.parse(s));
    }
    catch {
        setStorageError('Device storage is unavailable. Preview changes cannot be retained.');
    } setReady(true); }, []);
    function reset() { try {
        localStorage.removeItem('es-judge-interface-preview');
        setSaved(null);
        setRevision(n => n + 1);
        setList(false);
    }
    catch {
        setStorageError('Unable to clear device storage.');
    } }
    if (!ready)
        return <main><p>Loading judge preview…</p></main>;
    if (!full)
        return <div className="preview-studio"><header className="studio-header"><div><img src="/es-logo.png" alt="Entrepreneurs’ Society"/><div><span className="eyebrow">JUDGE INTERFACE PREVIEW</span><h1>Designed for the pitch.<br />Built for your phone.</h1><p>Try the real judging form using a fictional startup.<br />Preview scores stay on this device and never enter competition results.</p></div></div><a className="button" href="/">Competition workspace ↗</a></header><div className="studio-controls"><label>Phone width <select aria-label="Phone preview width" value={device} onChange={e => setDevice(e.target.value)}><option value="320">Small · 320px</option><option value="375">Compact · 375px</option><option value="390">Standard · 390px</option><option value="430">Large · 430px</option></select></label><a href="/judge-preview?view=full">Open full screen ↗</a></div><div className="phone-preview" style={{ width: Number(device) + 20 }}><div className="phone-speaker"/><iframe key={device} title="Mobile judge evaluation preview" src="/judge-preview?view=full" style={{ width: Number(device) }}/></div><p className="preview-caption">All seven criteria on one page · Tap to score · Separate sustainability Yes/No</p></div>;
    return <div className="mobile-judge-preview judge-shell"><header className="judge-mobile-header"><img src="/es-logo.png" alt="Entrepreneurs’ Society"/><div><strong>Startup Competition 2026</strong><small>Room 1 · Judge interface preview</small></div><span className="avatar">DJ</span></header><div className="preview-notice"><strong>PREVIEW ONLY</strong><span>Fictional startup. Saves on this device.</span><button onClick={reset}>Reset</button></div>{storageError && <div role="alert" className="alert">{storageError}</div>}<main className="preview-judge-main">{list ? <section className="panel padded"><span className="eyebrow">YOUR ASSIGNED STARTUPS</span><h1>Welcome, Demo Judge.</h1><p>One fictional startup is available in this preview.</p><button className="startup-card" onClick={() => setList(false)}><span className="badge">Preview</span><h3>{startup.name}</h3><p>{startup.description}</p><span className="card-link">Open evaluation →</span></button></section> : <Evaluation key={revision} startup={startup} judge={judge} saved={saved} locked={false} demo onBack={() => setList(true)} onSaved={() => { try {
        setSaved(JSON.parse(localStorage.getItem('es-judge-interface-preview') || 'null'));
    }
    catch { } }}/>}</main></div>;
}
