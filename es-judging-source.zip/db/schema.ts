import { sqliteTable, text, integer } from 'drizzle-orm/sqlite-core';
export const records = sqliteTable('records', { id: text('id').primaryKey(), kind: text('kind').notNull(), body: text('body').notNull(), version: integer('version').notNull().default(1) });
export const evaluations = sqliteTable('evaluations', { id: text('id').primaryKey(), judge: text('judge').notNull(), startup: text('startup').notNull(), body: text('body').notNull(), status: text('status').notNull().default('draft'), version: integer('version').notNull().default(1) });
export const audit = sqliteTable('audit', { id: text('id').primaryKey(), actor: text('actor').notNull(), action: text('action').notNull(), body: text('body').notNull(), time: text('time').notNull() });
