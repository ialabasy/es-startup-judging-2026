import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "ES Startup Competition · Judging",
  description: "Secure judging and administration for ES Startup Competition 2026.",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
