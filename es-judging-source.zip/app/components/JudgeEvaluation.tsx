'use client';
import { useState, useEffect, useRef } from 'react';
import { ArrowLeft, Info, Check, ChevronDown } from 'lucide-react';
import { criteria, score } from '../scoring';
import { api, download } from '../client-utils';
type Any = any;
export default function Evaluation({ startup, judge, saved, locked, onBack, onSaved, demo = false }: Any) {
    const [ratings, setRatings] = useState<(number | null)[]>(saved?.ratings || Array(7).fill(null)), [sustainability, setSustainability] = useState<boolean | null>(saved?.sustainability ?? null), [comments, setComments] = useState(saved?.comments || ''), [version, setVersion] = useState(saved?.version || 0), [state, setState] = useState(saved?.status === 'submitted' ? 'Submitted' : saved?.version ? demo ? 'Saved on this device' : 'All changes saved' : 'Ready'), [help, setHelp] = useState<number | null>(null), [err, setErr] = useState(''), [sending, setSending] = useState(false), [submitted, setSubmitted] = useState(saved?.status === 'submitted');
    const dirty = useRef(false), chain = useRef(Promise.resolve()), values = useRef<Any>({ ratings, sustainability, comments, version });
    values.current = { ratings, sustainability, comments, version };
    const disabled = submitted || locked || sending;
    const [rev, setRev] = useState(0);
    const changed = () => { dirty.current = true; setState('Unsaved changes'); setRev(n => n + 1); };
    const save = (submit = false) => {
        const snapshot = { ...values.current };
        chain.current = chain.current.catch(() => { }).then(async () => {
            setState('Saving…');
            let out: Any;
            if (demo) {
                out = { version: values.current.version + 1, status: submit ? 'submitted' : 'draft' };
                localStorage.setItem('es-judge-interface-preview', JSON.stringify({ ...snapshot, ...out }));
            }
            else
                out = await api({ action: 'saveEvaluation', startup: startup.id, judge: judge.id, ...snapshot, version: values.current.version, submit });
            values.current.version = out.version;
            setVersion(out.version);
            if (submit) {
                setSubmitted(true);
                setState('Submitted');
                onSaved();
            }
            else
                setState(demo ? 'Saved on this device' : 'All changes saved');
            setErr('');
        }).catch((e: Any) => { dirty.current = true; setState('Save failed'); setErr(e.message); throw e; });
        return chain.current;
    };
    useEffect(() => {
        if (!dirty.current || disabled)
            return;
        const t = setTimeout(() => { dirty.current = false; save().catch(() => { }); }, 600);
        return () => clearTimeout(t);
    }, [rev]);
    useEffect(() => {
        const f = (e: BeforeUnloadEvent) => {
            if (dirty.current || state === 'Saving…') {
                e.preventDefault();
                e.returnValue = '';
            }
        };
        window.addEventListener('beforeunload', f);
        return () => window.removeEventListener('beforeunload', f);
    }, [state]);
    useEffect(() => { const flush = () => { if (document.visibilityState === 'hidden' && dirty.current && !submitted && !locked) {
        dirty.current = false;
        save().catch(() => { });
    } }; document.addEventListener('visibilitychange', flush); return () => document.removeEventListener('visibilitychange', flush); }, [submitted, locked]);
    return <div className="judge-evaluation"><button className="text-button evaluation-back" onClick={async () => {
            try {
                if (dirty.current && !submitted)
                    await save();
                else
                    await chain.current;
            }
            catch {
                return;
            }
            onBack();
        }}><ArrowLeft size={16}/> All assigned startups</button><div className="evaluation-title"><div><span className="eyebrow">{startup.industry || 'STARTUP EVALUATION'}</span><h2>{startup.name}</h2><p>{startup.team} · {startup.description}</p></div><span role="status" aria-live="polite" className={'badge save-status ' + (state === 'All changes saved' || state === 'Saved on this device' || submitted ? 'green' : '')}>{state}</span></div><details className="panel startup-profile"><summary>Problem, solution & pitch deck <ChevronDown size={16}/></summary><div className="padded"><div className="detail-grid"><div><h4>Problem</h4><p>{startup.problem || 'Not provided'}</p></div><div><h4>Proposed solution</h4><p>{startup.solution || 'Not provided'}</p></div></div>{startup.deck && <a href={startup.deck} target="_blank" rel="noreferrer">Pitch deck ↗</a>}</div></details><div className="note"><Info size={18}/><span>Assess idea-stage reasoning and evidence. Traction, a working MVP, detailed forecasts and a complete GTM are not required.</span></div>{err && <div className="alert" role="alert">{err}<button onClick={() => save().catch(() => { })}>Retry save</button><button onClick={() => download('unsaved-evaluation.json', JSON.stringify({ startup: startup.id, judge: judge.id, ratings, sustainability, comments }, null, 2), 'application/json')}>Download local copy</button></div>}
    <section className="panel ratings-panel"><div className="panel-head"><h2>The seven criteria</h2><span className="muted small">1 = lowest · 5 = highest</span></div>{criteria.map((c, i) => <div className="criterion" key={c.name}><div className="criterion-label"><span className="criterion-no">0{i + 1}</span><div><h3>{c.name} <button className="info" aria-expanded={help === i} aria-label={'Scoring guide for ' + c.name} onClick={() => setHelp(help === i ? null : i)}><Info size={15}/></button></h3><small>{c.weight}% of total score</small></div></div><div className="ratings" role="group" aria-label={c.name}>{[1, 2, 3, 4, 5].map(n => <button disabled={disabled} key={n} aria-label={'Rate ' + n + ' out of 5'} aria-pressed={ratings[i] === n} className={ratings[i] === n ? 'chosen' : ''} onClick={() => { setRatings(r => r.map((x, k) => k === i ? n : x)); changed(); }}>{n}</button>)}</div>{help === i && <div className="anchors"><p>{c.about}</p>{c.anchors.map((a, k) => <p key={a}><b>{k + 1}</b> {a}</p>)}<small>Idea stage: evaluate credible reasoning and learning; do not require traction, a completed MVP, detailed forecasts or a full GTM.</small></div>}</div>)}</section><section className="panel padded sustainability"><div><span className="eyebrow">SEPARATE AWARD CONSIDERATION</span><h3>Does this startup demonstrate a meaningful environmental or social sustainability contribution?</h3><p>A credible positive contribution is central to the idea or meaningfully incorporated into the solution. This does not affect the weighted score.</p></div><div className="ratings">{[true, false].map(v => <button disabled={disabled} key={String(v)} className={sustainability === v ? 'chosen' : ''} aria-pressed={sustainability === v} onClick={() => { setSustainability(v); changed(); }}>{v ? 'YES' : 'NO'}</button>)}</div></section><section className="panel padded"><h3>Judge comments</h3><p>Record your observations, questions and useful feedback for the team.</p><textarea aria-label="Judge comments" className="comments" value={comments} maxLength={20000} disabled={disabled} onChange={e => { setComments(e.target.value); changed(); }} placeholder="What stands out? What should the team test next?"/></section><div className="submit-bar"><div><span className="muted small">{submitted ? 'Submitted score' : 'Current weighted score'}</span><strong>{score(ratings).toFixed(2)} <small>/ 100</small></strong><small>{ratings.filter(Boolean).length}/7 criteria completed{ratings.some(x => x === null) ? ' · provisional' : ''}</small></div><div><p className="small muted">{submitted ? demo ? 'Preview submitted. Reset to try again.' : 'Locked. Contact ES Academics to request reopening.' : ratings.some(x => x === null) ? 'Complete all seven ratings to submit.' : sustainability === null ? 'Choose sustainability Yes or No.' : 'Ready to submit. Ratings lock after submission.'}</p>{!submitted && <button className="primary" disabled={disabled || ratings.some(x => x === null) || sustainability === null} onClick={async () => {
                if (!confirm(demo ? 'Submit this preview? It locks the demo evaluation until you reset it. No competition results are changed.' : 'Submit and lock this evaluation? Only an administrator can reopen it.'))
                    return;
                setSending(true);
                try {
                    await save(true);
                    dirty.current = false;
                }
                catch { }
                finally {
                    setSending(false);
                }
            }}><Check size={17}/> {sending ? 'Submitting…' : demo ? 'Submit preview' : 'Submit evaluation'}</button>}</div></div></div>;
}
