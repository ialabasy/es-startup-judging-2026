type Any = any;
export async function api(body?: Any) {
    const r = await fetch('/api/platform', { method: body ? 'POST' : 'GET', headers: body ? { 'Content-Type': 'application/json' } : undefined, body: body ? JSON.stringify(body) : undefined, keepalive: body?.action === 'saveEvaluation' });
    const d: any = await r.json();
    if (!r.ok)
        throw new Error(d.error || 'Request failed');
    return d;
}
export function download(name: string, content: string, type = 'text/csv') { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([content], { type })); a.download = name; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 1000); }
