import { env } from 'cloudflare:workers';
import { criteria, validRatings, score } from '../../scoring';
const adminEmails = ['ismail.alabasy@gmail.com', 'ismailalabasy@aucegypt.edu'];
const json = (v: any, status = 200) => Response.json(v, { status, headers: { 'Cache-Control': 'no-store' } });
const rid = () => crypto.randomUUID();
async function all(db: any, kind: string) { const q = await db.prepare('SELECT * FROM records WHERE kind=?').bind(kind).all(); return q.results.map((r: any) => ({ ...JSON.parse(r.body), id: r.id, version: r.version })); }
async function evaluationRows(db: any) { const q = await db.prepare('SELECT * FROM evaluations').all(); return q.results.map((r: any) => ({ ...JSON.parse(r.body), id: r.id, judge: r.judge, startup: r.startup, status: r.status, version: r.version })); }
function rec(db: any, kind: string, item: any) { return db.prepare('INSERT INTO records(id,kind,body) VALUES(?,?,?) ON CONFLICT(id) DO UPDATE SET body=excluded.body,version=records.version+1').bind(item.id, kind, JSON.stringify(item)); }
function log(db: any, actor: string, action: string, data: any) { return db.prepare('INSERT INTO audit VALUES(?,?,?,?,?)').bind(rid(), actor, action, JSON.stringify(data), new Date().toISOString()); }
function err(msg: string, status = 400): never { throw Object.assign(new Error(msg), { status }); }
function safeUrl(x: any) { return !x || (/^https:\/\//i.test(x) && x.length < 2000); }
async function identity(req: Request, db: any) { const uid = req.headers.get('oai-authenticated-user-id'); const email = req.headers.get('oai-authenticated-user-email')?.toLowerCase(); if (!uid || !email)
    err('Sign in to continue.', 401); const admins = await all(db, 'admin'); if (adminEmails.includes(email) || admins.some((a: any) => a.email === email))
    return { id: uid, email, role: 'admin', name: adminEmails.includes(email) ? 'Ismail' : admins.find((a: any) => a.email === email).name }; const judges = await all(db, 'judge'); const j = judges.find((j: any) => j.email?.toLowerCase() === email && j.active !== false); if (!j)
    err('Your account has not been assigned. Contact ES Academics.', 403); if (j.userId && j.userId !== uid)
    err('Account identity mismatch. Contact an administrator.', 403); if (!j.userId) {
    await db.prepare("UPDATE records SET body=json_set(body,'$.userId',?),version=version+1 WHERE id=? AND json_extract(body,'$.userId') IS NULL").bind(uid, j.id).run();
    const rr = await db.prepare('SELECT body FROM records WHERE id=?').bind(j.id).first();
    if (JSON.parse(rr.body).userId !== uid)
        err('Account already linked.', 403);
} return { ...j, role: 'judge' }; }
export async function GET(req: Request) { try {
    const db = env.DB!;
    const me = await identity(req, db);
    const [rooms, startups, judges, settings, evals] = await Promise.all([all(db, 'room'), all(db, 'startup'), all(db, 'judge'), all(db, 'settings'), evaluationRows(db)]);
    if (me.role === 'admin') {
        const a = await db.prepare('SELECT * FROM audit ORDER BY time DESC LIMIT 500').all();
        return json({ me, rooms, startups, judges, admins: await all(db, 'admin'), settings: settings[0] || { id: 'settings', threshold: 20, target: 6, locked: false }, evaluations: evals, audit: a.results });
    }
    return json({ me, rooms: rooms.filter((r: any) => r.id === me.room), startups: startups.filter((s: any) => s.room === me.room), judges: judges.filter((j: any) => j.room === me.room && j.active !== false).map(({ id, name, organization, title, linkedin, room }: any) => ({ id, name, organization, title, linkedin, room })), evaluations: evals.filter((e: any) => e.judge === me.id), settings: { locked: settings[0]?.locked || false } });
}
catch (e: any) {
    return json({ error: e.message }, e.status || 500);
} }
export async function POST(req: Request) {
    try {
        if (req.headers.get('origin') !== new URL(req.url).origin)
            err('Invalid request origin.', 403);
        const db = env.DB!;
        const me = await identity(req, db);
        const body: any = await req.json();
        const { action } = body;
        const settings = (await all(db, 'settings'))[0] || { id: 'settings', threshold: 20, target: 6, locked: false };
        if (action === 'saveEvaluation') {
            let judge = me;
            if (me.role === 'admin') {
                const js = await all(db, 'judge');
                judge = js.find((j: any) => j.id === body.judge && j.demo);
                if (!judge)
                    err('Admin rehearsal is limited to fictional judges.', 403);
            }
            if (settings.locked)
                err('Results are locked.', 409);
            const s = (await all(db, 'startup')).find((s: any) => s.id === body.startup);
            if (!s || s.room !== judge.room || judge.active === false)
                err('This startup is not assigned to you.', 403);
            const ratings = body.ratings;
            if (!Array.isArray(ratings) || ratings.length !== 7 || !ratings.every((n: any) => n === null || (Number.isInteger(n) && n >= 1 && n <= 5)))
                err('Invalid ratings.');
            if (![null, true, false].includes(body.sustainability))
                err('Invalid sustainability answer.');
            if (typeof body.comments !== 'string' || body.comments.length > 20000)
                err('Comments must be under 20,000 characters.');
            if (body.submit && (!validRatings(ratings) || typeof body.sustainability !== 'boolean'))
                err('Complete all seven ratings and sustainability before submitting.');
            const id = judge.id + ':' + s.id;
            const payload = JSON.stringify({ ratings, sustainability: body.sustainability, comments: body.comments, total: body.submit ? score(ratings) : null, updatedAt: new Date().toISOString() });
            const status = body.submit ? 'submitted' : 'draft';
            const v = Number(body.version) || 0;
            let statement;
            if (v === 0)
                statement = db.prepare('INSERT OR IGNORE INTO evaluations(id,judge,startup,body,status,version) VALUES(?,?,?,?,?,1)').bind(id, judge.id, s.id, payload, status);
            else
                statement = db.prepare("UPDATE evaluations SET body=?,status=?,version=version+1 WHERE id=? AND version=? AND status='draft'").bind(payload, status, id, v);
            const out = await db.batch([statement, log(db, me.id, body.submit ? 'submit evaluation attempt' : 'save draft attempt', { id, expectedVersion: v })]);
            if (!out[0].meta.changes)
                err('This evaluation changed in another tab or is locked. Reload before continuing.', 409);
            return json({ version: v + 1, status, total: body.submit ? score(ratings) : null });
        }
        if (me.role !== 'admin')
            err('Administrator access required.', 403);
        if (action === 'adminAccess') {
            if (!adminEmails.includes(me.email))
                err('Only the owner can manage administrators.', 403);
            if (body.remove) {
                await db.batch([db.prepare("DELETE FROM records WHERE kind='admin' AND id=?").bind(body.id), log(db, me.id, 'remove administrator', { id: body.id })]);
                return json({ ok: true });
            }
            if (!body.name?.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(body.email))
                err('Name and valid email required.');
            const a = { id: 'admin-' + body.email.toLowerCase(), name: body.name.trim(), email: body.email.toLowerCase() };
            await db.batch([rec(db, 'admin', a), log(db, me.id, 'add administrator', a)]);
            return json({ ok: true });
        }
        if (action === 'backup') {
            const records = await db.prepare('SELECT * FROM records').all();
            const evaluations = await db.prepare('SELECT * FROM evaluations').all();
            const audit = await db.prepare('SELECT * FROM audit').all();
            return json({ format: 'es-judging-backup-v1', createdAt: new Date().toISOString(), records: records.results, evaluations: evaluations.results, audit: audit.results });
        }
        if (action === 'reopen') {
            if (settings.locked)
                err('Unlock results first.', 409);
            if (!body.reason?.trim())
                err('A reason is required.');
            await db.batch([db.prepare("UPDATE evaluations SET status='draft',version=version+1 WHERE id=?").bind(body.id), log(db, me.id, 'reopen evaluation', { id: body.id, reason: body.reason })]);
            return json({ ok: true });
        }
        if (action === 'settings') {
            const next = { ...settings, threshold: Number(body.threshold), target: Number(body.target), locked: !!body.locked };
            if (![6, 8].includes(next.target) || !Number.isFinite(next.threshold) || next.threshold < 1 || next.threshold > 100)
                err('Invalid settings.');
            if (next.locked) {
                const s = await all(db, 'startup');
                if (s.filter((x: any) => x.finalist).length !== next.target)
                    err(`Select exactly ${next.target} finalists before locking.`);
            }
            await db.batch([rec(db, 'settings', next), log(db, me.id, 'update settings', next)]);
            return json({ ok: true });
        }
        if (settings.locked)
            err('Results are locked. Unlock results to make changes.', 409);
        if (action === 'upsert') {
            const kind = body.kind;
            if (!['room', 'judge', 'startup'].includes(kind))
                err('Invalid record type.');
            const a = body.item;
            if (typeof a.name !== 'string' || !a.name.trim() || a.name.length > 200)
                err('Name is required, up to 200 characters.');
            const previous = a.id ? await db.prepare('SELECT * FROM records WHERE id=?').bind(a.id).first() : null;
            if (previous && previous.kind !== kind)
                err('Record type mismatch.');
            const old = previous ? JSON.parse(String(previous.body)) : null;
            if (kind === 'judge' && (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(a.email) || !safeUrl(a.linkedin)))
                err('Enter a valid email and HTTPS LinkedIn URL.');
            if (kind === 'startup' && !safeUrl(a.deck))
                err('Pitch deck link must use HTTPS.');
            if (kind !== 'room' && a.room) {
                const rooms = await all(db, 'room');
                if (!rooms.some((r: any) => r.id === a.room))
                    err('Select an existing room.');
            }
            if (kind === 'judge') {
                const judges = await all(db, 'judge');
                if (judges.some((j: any) => j.id !== a.id && j.email?.toLowerCase() === a.email.toLowerCase()))
                    err('This judge email already exists.');
                if (a.room && a.active !== false && judges.filter((j: any) => j.id !== a.id && j.room === a.room && j.active !== false).length >= 3)
                    err('A room may have at most three active judges.');
            }
            if (old && ((old.room !== a.room) || (kind === 'judge' && old.active !== a.active))) {
                const es = await evaluationRows(db);
                if (es.some((e: any) => kind === 'startup' ? e.startup === a.id : e.judge === a.id))
                    err('Assignments cannot change after evaluation has started.');
            }
            if (kind === 'room' && !old && (await all(db, 'room')).length >= 5)
                err('The filtration event supports five rooms.');
            const fields: any = kind === 'room' ? ['name'] : kind === 'judge' ? ['name', 'email', 'organization', 'title', 'linkedin', 'room', 'active'] : ['name', 'team', 'description', 'problem', 'solution', 'industry', 'room', 'deck'];
            const item: any = { ...old, id: old?.id || a.id || rid() };
            for (const f of fields)
                item[f] = a[f] ?? (f === 'active' ? true : '');
            if (old?.demo)
                item.demo = true;
            if (old?.userId)
                item.userId = old.userId;
            await db.batch([rec(db, kind, item), log(db, me.id, 'save ' + kind, item)]);
            return json({ ok: true, id: item.id });
        }
        if (action === 'remove') {
            const row = await db.prepare('SELECT * FROM records WHERE id=?').bind(body.id).first();
            if (!row || !['room', 'startup', 'judge'].includes(String(row.kind)))
                err('Record not found.');
            const es = await evaluationRows(db);
            if (es.some((e: any) => e.startup === body.id || e.judge === body.id))
                err('Cannot remove a record with evaluations.');
            if (row.kind === 'room') {
                const r = [...await all(db, 'judge'), ...await all(db, 'startup')];
                if (r.some((x: any) => x.room === body.id))
                    err('Remove room assignments first.');
            }
            await db.batch([db.prepare('DELETE FROM records WHERE id=?').bind(body.id), log(db, me.id, 'remove ' + row.kind, { id: body.id })]);
            return json({ ok: true });
        }
        if (action === 'finalist' || action === 'exception') {
            const s = (await all(db, 'startup')).find((x: any) => x.id === body.id);
            if (!s)
                err('Startup not found.');
            if (!body.reason?.trim())
                err('Record a reason for this decision.');
            if (action === 'finalist') {
                s.finalist = !!body.selected;
                s.finalistReason = body.reason;
            }
            else
                s.exception = body.reason;
            await db.batch([rec(db, 'startup', s), log(db, me.id, action, { id: s.id, selected: body.selected, reason: body.reason })]);
            return json({ ok: true });
        }
        if (action === 'seed') {
            if ((await all(db, 'startup')).length || (await all(db, 'judge')).length)
                err('Rehearsal data requires an empty competition.');
            const st = [];
            for (let i = 1; i <= 5; i++) {
                st.push(rec(db, 'room', { id: 'demo-room-' + i, name: 'Room ' + i, demo: true }));
                for (let j = 1; j <= (i % 2 ? 3 : 2); j++)
                    st.push(rec(db, 'judge', { id: `demo-judge-${i}-${j}`, name: `Demo Judge ${i}.${j}`, email: `judge${i}${j}@example.invalid`, organization: 'Fictional Ventures', room: 'demo-room-' + i, active: true, demo: true }));
                for (let k = 1; k <= 10; k++)
                    st.push(rec(db, 'startup', { id: `demo-startup-${i}-${k}`, name: ['Sprout', 'Loop', 'Nile', 'Bright', 'Orbit'][i - 1] + ' ' + String(k).padStart(2, '0'), team: `Fictional Team ${i}.${k}`, description: 'Fictional idea-stage startup for platform rehearsal. Not an actual competition entry.', problem: 'Students struggle to find reliable, affordable resources.', solution: 'A simple shared service to connect students with resources.', industry: ['AgriTech', 'Circular economy', 'EdTech', 'HealthTech', 'FinTech'][i - 1], room: 'demo-room-' + i, demo: true }));
            }
            await db.batch([...st, log(db, me.id, 'create fictional rehearsal data', { startups: 50, judges: 13 })]);
            return json({ ok: true });
        }
        if (action === 'clearDemo') {
            const ss = await all(db, 'startup'), jj = await all(db, 'judge'), rr = await all(db, 'room');
            const ids = [...ss, ...jj, ...rr].filter((x: any) => x.demo).map((x: any) => x.id);
            const batch = [];
            for (const id of ids) {
                batch.push(db.prepare('DELETE FROM evaluations WHERE startup=? OR judge=?').bind(id, id));
                batch.push(db.prepare('DELETE FROM records WHERE id=?').bind(id));
            }
            if (batch.length)
                await db.batch([...batch, log(db, me.id, 'clear fictional rehearsal', { records: ids.length })]);
            return json({ ok: true });
        }
        err('Unknown action.');
    }
    catch (e: any) {
        return json({ error: e.message }, e.status || 500);
    }
}
