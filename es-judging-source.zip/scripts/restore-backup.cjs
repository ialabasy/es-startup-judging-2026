// Generate an operator-reviewed transactional restore script; never runs it automatically.
const fs=require('node:fs');
const input=process.argv[2],output=process.argv[3];
if(!input||!output)throw new Error('Usage: node scripts/restore-backup.cjs BACKUP.json restore.sql');
const b=JSON.parse(fs.readFileSync(input,'utf8'));
if(b.format!=='es-judging-backup-v1'||!Array.isArray(b.records)||!Array.isArray(b.evaluations)||!Array.isArray(b.audit))throw new Error('Unsupported backup');
const quote=v=>v===null?'NULL':typeof v==='number'?String(v):"'"+String(v).replaceAll("'","''")+"'";
const sql=['-- Full restore. Review and back up the target database before applying.','DELETE FROM evaluations;','DELETE FROM records;','DELETE FROM audit;'];
for(const [table,fields] of [['records',['id','kind','body','version']],['evaluations',['id','judge','startup','body','status','version']],['audit',['id','actor','action','body','time']]])for(const r of b[table]){if(fields.some(f=>r[f]===undefined))throw new Error('Invalid '+table+' record');sql.push(`INSERT INTO ${table} (${fields.join(',')}) VALUES (${fields.map(f=>quote(r[f])).join(',')});`)}
fs.writeFileSync(output,sql.join('\n')+'\n',{flag:'wx'});console.log('Restore SQL generated. Review before applying to the intended database.');
